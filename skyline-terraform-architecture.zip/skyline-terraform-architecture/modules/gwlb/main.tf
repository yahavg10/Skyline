# GWLB resources

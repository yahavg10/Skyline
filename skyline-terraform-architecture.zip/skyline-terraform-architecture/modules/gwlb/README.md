GWLB Module

Gateway Load Balancer and endpoints.

# GWLB parameters

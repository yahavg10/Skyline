# Common tagging strategy

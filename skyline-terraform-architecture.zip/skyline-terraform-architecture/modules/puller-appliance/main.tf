# Resources: ASG, Launch Template, ENI

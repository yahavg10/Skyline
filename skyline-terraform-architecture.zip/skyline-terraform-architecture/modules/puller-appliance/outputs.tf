# Exposed outputs (ENI IDs, ASG name)

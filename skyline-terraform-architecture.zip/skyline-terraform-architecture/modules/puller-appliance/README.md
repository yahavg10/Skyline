Puller Appliance Module

Encapsulates EC2 + ASG + ENI + routing for a network appliance.

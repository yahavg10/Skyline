# All required inputs for the appliance

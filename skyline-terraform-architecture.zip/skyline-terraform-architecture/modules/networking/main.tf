# VPC and subnet definitions

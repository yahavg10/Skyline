# VPC ID, subnet IDs

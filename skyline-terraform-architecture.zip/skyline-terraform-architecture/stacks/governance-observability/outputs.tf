# outputs.tf for governance-observability

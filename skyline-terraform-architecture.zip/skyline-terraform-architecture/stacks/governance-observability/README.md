Tier 4 – Governance & Observability

Logging, monitoring, access.

# variables.tf for governance-observability

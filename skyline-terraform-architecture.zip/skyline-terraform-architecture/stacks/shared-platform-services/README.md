Tier 2 – Shared Platform Services

ALB, ECS, ECR, endpoints.

# data.tf for shared-platform-services

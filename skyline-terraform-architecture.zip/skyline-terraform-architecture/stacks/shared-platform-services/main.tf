# main.tf for shared-platform-services

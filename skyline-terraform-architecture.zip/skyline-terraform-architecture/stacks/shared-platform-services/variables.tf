# variables.tf for shared-platform-services

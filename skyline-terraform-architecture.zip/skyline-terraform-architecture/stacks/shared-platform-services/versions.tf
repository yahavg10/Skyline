# versions.tf for shared-platform-services

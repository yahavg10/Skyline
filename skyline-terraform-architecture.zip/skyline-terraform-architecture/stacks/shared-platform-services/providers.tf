# providers.tf for shared-platform-services

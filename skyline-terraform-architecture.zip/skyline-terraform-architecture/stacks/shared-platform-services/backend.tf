# backend.tf for shared-platform-services

# outputs.tf for shared-platform-services

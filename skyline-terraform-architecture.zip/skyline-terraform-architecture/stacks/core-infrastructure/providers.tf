# providers.tf for core-infrastructure

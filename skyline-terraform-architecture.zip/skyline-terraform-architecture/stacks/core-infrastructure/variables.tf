# variables.tf for core-infrastructure

# versions.tf for core-infrastructure

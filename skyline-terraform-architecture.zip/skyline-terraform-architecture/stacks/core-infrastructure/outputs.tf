# outputs.tf for core-infrastructure

# data.tf for core-infrastructure

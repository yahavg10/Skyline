Tier 0 – Core Infrastructure

Rarely changes. Owns VPC, subnets, routing.

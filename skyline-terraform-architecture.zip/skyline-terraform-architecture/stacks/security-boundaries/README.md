Tier 1 – Security Boundaries

Owns firewall appliances and traffic enforcement.

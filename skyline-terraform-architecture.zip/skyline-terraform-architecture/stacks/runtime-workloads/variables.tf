# variables.tf for runtime-workloads

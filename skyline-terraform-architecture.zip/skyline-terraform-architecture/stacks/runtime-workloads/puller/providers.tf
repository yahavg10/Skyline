# providers.tf for puller workload

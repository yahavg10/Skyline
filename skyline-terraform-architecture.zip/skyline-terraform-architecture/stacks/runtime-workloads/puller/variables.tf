# variables.tf for puller workload

Runtime workload: Puller

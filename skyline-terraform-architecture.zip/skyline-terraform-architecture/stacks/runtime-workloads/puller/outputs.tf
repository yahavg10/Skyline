# outputs.tf for puller workload

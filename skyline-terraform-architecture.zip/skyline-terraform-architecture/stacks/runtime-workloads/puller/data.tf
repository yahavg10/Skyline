# data.tf for puller workload
